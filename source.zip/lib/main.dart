import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

const String API_BASE_URL = 'http://us2-p.plutonodes.net:25000/wallet';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Substrate Wallet',
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.blue,
      ),
      home: WalletHomePage(),
    );
  }
}

class WalletHomePage extends StatefulWidget {
  @override
  _WalletHomePageState createState() => _WalletHomePageState();
}

class _WalletHomePageState extends State<WalletHomePage> {
  String walletAddress = '';
  String privateKey = '';
  Map<String, dynamic> walletInfo = {};
  List<dynamic> transactions = [];
  bool isLoading = false;
  int _currentIndex = 0;

  TextEditingController addressController = TextEditingController();
  TextEditingController privateKeyController = TextEditingController();
  TextEditingController receiverController = TextEditingController();
  TextEditingController amountController = TextEditingController();
  String selectedCurrency = 'XPL';

  @override
  void initState() {
    super.initState();
    loadSavedWallet();
  }

  void loadSavedWallet() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      walletAddress = prefs.getString('walletAddress') ?? '';
      privateKey = prefs.getString('privateKey') ?? '';
    });
    if (walletAddress.isNotEmpty && privateKey.isNotEmpty) {
      loadWallet();
    }
  }

  void saveWallet(String address, String key) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setString('walletAddress', address);
    await prefs.setString('privateKey', key);
  }

  Future<void> createWallet() async {
    setState(() {
      isLoading = true;
    });
    try {
      final url = Uri.parse('$API_BASE_URL/external/create');
      final response = await http.post(url);
      if (response.statusCode == 200) {
        final wallet = json.decode(response.body);
        setState(() {
          walletAddress = wallet['address'];
          privateKey = wallet['privateKey'];
          walletInfo = wallet;
        });
        saveWallet(walletAddress, privateKey);
        loadTransactions();
        showPrivateKeyDialog();
      } else {
        throw Exception('Failed to create wallet');
      }
    } catch (e) {
      showAlert('Error', 'Failed to create wallet: $e');
    } finally {
      setState(() {
        isLoading = false;
      });
    }
  }

  void showPrivateKeyDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Save Your Private Key'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Please save your private key in a secure location. You will need it to access your wallet.'),
              SizedBox(height: 10),
              SelectableText(privateKey, style: TextStyle(fontWeight: FontWeight.bold)),
            ],
          ),
          actions: <Widget>[
            TextButton(
              child: Text('I have saved it'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  Future<void> loadWallet() async {
    setState(() {
      isLoading = true;
    });
    try {
      final response = await http.get(Uri.parse('$API_BASE_URL/external/$walletAddress'));
      if (response.statusCode == 200) {
        setState(() {
          walletInfo = json.decode(response.body);
        });
        loadTransactions();
      } else {
        throw Exception('Failed to load wallet');
      }
    } catch (e) {
      showAlert('Error', 'Failed to load wallet: $e');
    } finally {
      setState(() {
        isLoading = false;
      });
    }
  }

  Future<void> loadTransactions() async {
    try {
      final response = await http.get(Uri.parse('$API_BASE_URL/external/$walletAddress/transactions'));
      if (response.statusCode == 200) {
        setState(() {
          transactions = json.decode(response.body);
        });
      } else {
        throw Exception('Failed to load transactions');
      }
    } catch (e) {
      showAlert('Error', 'Failed to load transactions: $e');
    }
  }

  Future<void> transfer() async {
    setState(() {
      isLoading = true;
    });
    try {
      final transferData = {
        'senderAddress': walletAddress,
        'privateKey': privateKey,
        'receiverId': receiverController.text,
        'amount': int.parse(amountController.text),
        'currency': selectedCurrency,
      };
      final response = await http.post(
        Uri.parse('$API_BASE_URL/external/transfer'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode(transferData),
      );
      if (response.statusCode == 200) {
        final result = json.decode(response.body);
        showAlert('Success', result['message']);
        loadWallet();
      } else {
        throw Exception('Failed to transfer funds');
      }
    } catch (e) {
      showAlert('Error', 'Failed to transfer funds: $e');
    } finally {
      setState(() {
        isLoading = false;
      });
    }
  }

  void showAlert(String title, String message) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(title),
          content: Text(message),
          actions: <Widget>[
            TextButton(
              child: Text('OK'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  void showLoadWalletDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Load Existing Wallet'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: addressController,
                decoration: InputDecoration(labelText: 'Wallet Address'),
              ),
              TextField(
                controller: privateKeyController,
                decoration: InputDecoration(labelText: 'Private Key'),
                obscureText: true,
              ),
            ],
          ),
          actions: <Widget>[
            TextButton(
              child: Text('Cancel'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
            TextButton(
              child: Text('Load'),
              onPressed: () {
                setState(() {
                  walletAddress = addressController.text;
                  privateKey = privateKeyController.text;
                });
                saveWallet(walletAddress, privateKey);
                loadWallet();
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  void logoutWallet() {
    setState(() {
      walletAddress = '';
      privateKey = '';
      walletInfo = {};
      transactions = [];
    });
    saveWallet('', '');
  }

  void _showColorPicker() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Choose Theme Color'),
          content: SingleChildScrollView(
            child: ColorPicker(
              pickerColor: Theme.of(context).colorScheme.primary,
              onColorChanged: (Color color) {
                setState(() {
                });
              },
              pickerAreaHeightPercent: 0.8,
            ),
          ),
          actions: <Widget>[
            TextButton(
              child: Text('Done'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Substrate Wallet')
      ),
      body: IndexedStack(
        index: _currentIndex,
        children: [
          _buildHomeTab(),
          _buildTransferTab(),
          _buildTransactionsTab(),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (index) {
          setState(() {
            _currentIndex = index;
          });
        },
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.send), label: 'Transfer'),
          BottomNavigationBarItem(icon: Icon(Icons.history), label: 'Transactions'),
        ],
      ),
    );
  }

  Widget _buildHomeTab() {
    return SingleChildScrollView(
      padding: EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Card(
            child: Padding(
              padding: EdgeInsets.all(16.0),
              child: Column(
                children: [
                  Image.network('https://i.imgur.com/RX3riDU.png', height: 100),
                  SizedBox(height: 20),
                  if (walletAddress.isNotEmpty) ...[
                    Text('Address: $walletAddress', style: TextStyle(fontSize: 16)),
                    SizedBox(height: 10),
                    Text('XPL Balance: ${walletInfo['xpl'] ?? 0}', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                    Text('XRS Balance: ${walletInfo['xrs'] ?? 0}', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  ] else ...[
                    Text('No wallet loaded', style: TextStyle(fontSize: 18)),
                    SizedBox(height: 10),
                    ElevatedButton(
                      child: Text('Create Wallet'),
                      onPressed: createWallet,
                    ),
                    TextButton(
                      child: Text('Load Existing Wallet'),
                      onPressed: showLoadWalletDialog,
                    ),
                  ],
                ],
              ),
            ),
          ),
          if (walletAddress.isNotEmpty)
            Padding(
              padding: EdgeInsets.only(top: 16.0),
              child: ElevatedButton(
                child: Text('Logout'),
                onPressed: logoutWallet
              ),
            ),
          if (isLoading)
            Center(child: CircularProgressIndicator()),
        ],
      ),
    );
  }

  Widget _buildTransferTab() {
    return SingleChildScrollView(
      padding: EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          TextField(
            controller: receiverController,
            decoration: InputDecoration(labelText: 'Receiver Address'),
          ),
          SizedBox(height: 10),
          TextField(
            controller: amountController,
            decoration: InputDecoration(labelText: 'Amount'),
            keyboardType: TextInputType.number,
          ),
          SizedBox(height: 10),
          DropdownButton<String>(
            value: selectedCurrency,
            items: ['XPL', 'XRS'].map((String value) {
              return DropdownMenuItem<String>(
                value: value,
                child: Text(value),
              );
            }).toList(),
            onChanged: (String? newValue) {
              setState(() {
                selectedCurrency = newValue!;
              });
            },
          ),
          SizedBox(height: 20),
          ElevatedButton(
            child: Text('Transfer'),
            onPressed: transfer,
          ),
        ],
      ),
    );
  }

  Widget _buildTransactionsTab() {
    return ListView.builder(
      itemCount: transactions.length,
      itemBuilder: (context, index) {
        final transaction = transactions[index];
        return Card(
          margin: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
          child: ListTile(
            title: Text('${transaction['amount']} ${transaction['currency']}'),
            subtitle: Text('From: ${transaction['senderId']}\nTo: ${transaction['receiverId']}'),
            trailing: Text(DateTime.fromMillisecondsSinceEpoch(transaction['timestamp']).toString()),
          ),
        );
      },
    );
  }
}

class ColorPicker extends StatelessWidget {
  final Color pickerColor;
  final ValueChanged<Color> onColorChanged;
  final double pickerAreaHeightPercent;

  const ColorPicker({
    Key? key,
    required this.pickerColor,
    required this.onColorChanged,
    this.pickerAreaHeightPercent = 1.0,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 300,
      height: 300 * pickerAreaHeightPercent,
      child: ColorPicker(
        pickerColor: pickerColor,
        onColorChanged: onColorChanged,
        pickerAreaHeightPercent: pickerAreaHeightPercent,
      ),
    );
  }
}